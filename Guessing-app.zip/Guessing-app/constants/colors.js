export default {
    primary: '#f7287b',
    accent: '#c717fc'
};