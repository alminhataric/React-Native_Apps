export default {
  /* primaryColor: '#8B008B',
    accentColor: '#ff6f00' */

  primaryColor: "#4a148c",
  accentColor: "#ff6f00",
};
